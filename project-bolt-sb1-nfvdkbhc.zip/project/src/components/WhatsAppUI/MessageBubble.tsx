import React, { useState } from 'react';
import { Check, Trash2, Edit2 } from 'lucide-react';
import { Message } from '../../types';

interface MessageBubbleProps {
  message: Message;
  platform: 'ios' | 'android';
  editable?: boolean;
  onEdit?: (id: string, text: string) => void;
  onDelete?: (id: string) => void;
}

const MessageBubble: React.FC<MessageBubbleProps> = ({
  message,
  platform,
  editable = false,
  onEdit,
  onDelete
}) => {
  const [isEditing, setIsEditing] = useState(false);
  const [editText, setEditText] = useState(message.text);
  const [showActions, setShowActions] = useState(false);
  
  const handleSaveEdit = () => {
    if (onEdit && editText.trim()) {
      onEdit(message.id, editText);
    }
    setIsEditing(false);
  };
  
  const messageClass = platform === 'ios' ? 'ios-message' : 'android-message';
  const statusClass = message.isSent ? 'message-sent' : 'message-received';
  
  return (
    <div 
      className={`flex ${message.isSent ? 'justify-end' : 'justify-start'} relative`}
      onMouseEnter={() => editable && setShowActions(true)}
      onMouseLeave={() => editable && setShowActions(false)}
    >
      <div className={`${messageClass} ${statusClass} relative`}>
        {isEditing ? (
          <div className="flex flex-col">
            <textarea
              value={editText}
              onChange={(e) => setEditText(e.target.value)}
              className="p-1 rounded border border-gray-300 focus:outline-none focus:border-[#128C7E] resize-none min-h-[60px] w-full"
              autoFocus
            />
            <div className="flex justify-end mt-1">
              <button
                onClick={handleSaveEdit}
                className="text-[#128C7E] p-1 rounded-full hover:bg-gray-100"
              >
                <Check size={16} />
              </button>
            </div>
          </div>
        ) : (
          <>
            <p className="whitespace-pre-wrap break-words">{message.text}</p>
            <div className="flex justify-end items-center mt-1 space-x-1">
              <span className="text-xs text-gray-500">{message.timestamp}</span>
              {message.isSent && (
                <span className="text-xs text-[#0DA2CD]">
                  <Check size={14} className="inline-block" />
                  <Check size={14} className="inline-block -ml-2" />
                </span>
              )}
            </div>
          </>
        )}
      </div>
      
      {/* Edit/Delete buttons for editable mode */}
      {editable && showActions && !isEditing && (
        <div className="absolute top-0 left-0 flex space-x-1 bg-white rounded-full shadow p-1 -ml-2 -mt-2">
          <button
            onClick={() => setIsEditing(true)}
            className="text-blue-500 p-1 rounded-full hover:bg-gray-100"
            title="Editar"
          >
            <Edit2 size={12} />
          </button>
          <button
            onClick={() => onDelete && onDelete(message.id)}
            className="text-red-500 p-1 rounded-full hover:bg-gray-100"
            title="Excluir"
          >
            <Trash2 size={12} />
          </button>
        </div>
      )}
    </div>
  );
};

export default MessageBubble;