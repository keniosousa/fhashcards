import React from 'react';
import { ChevronLeft, Phone, Video, MoreVertical } from 'lucide-react';
import { Conversation, Message } from '../../types';
import MessageBubble from './MessageBubble';
import InputBar from './InputBar';

interface IOSChatProps {
  conversation: Conversation;
  editable?: boolean;
  onMessageEdit?: (id: string, text: string) => void;
  onMessageDelete?: (id: string) => void;
}

const IOSChat: React.FC<IOSChatProps> = ({
  conversation,
  editable = false,
  onMessageEdit,
  onMessageDelete
}) => {
  const { contact, messages } = conversation;
  
  // Group messages by date (just for display, not actually implemented)
  const messagesWithHeaders = messages;
  
  return (
    <div className="flex flex-col h-full w-full bg-[#E4DDD6] overflow-hidden">
      {/* Header */}
      <div className="ios-header flex items-center px-4 py-3 z-10">
        <div className="flex items-center">
          <ChevronLeft size={24} className="text-[#075E54] mr-1" />
          <div className="h-9 w-9 rounded-full overflow-hidden mr-3">
            <img
              src={contact.photoUrl || 'https://images.pexels.com/photos/614810/pexels-photo-614810.jpeg?auto=compress&cs=tinysrgb&w=200'}
              alt={contact.name}
              className="h-full w-full object-cover"
            />
          </div>
        </div>
        
        <div className="flex-1">
          <h3 className="font-semibold">{contact.name}</h3>
          <p className="text-xs text-gray-500">
            {contact.isOnline ? 'online' : contact.lastSeen}
          </p>
        </div>
        
        <div className="flex items-center space-x-4">
          <Video size={20} className="text-[#075E54]" />
          <Phone size={20} className="text-[#075E54]" />
          <MoreVertical size={20} className="text-[#075E54]" />
        </div>
      </div>
      
      {/* Chat Area */}
      <div className="flex-1 overflow-y-auto p-3 space-y-2">
        {messagesWithHeaders.map((message) => (
          <MessageBubble
            key={message.id}
            message={message}
            platform="ios"
            editable={editable}
            onEdit={onMessageEdit}
            onDelete={onMessageDelete}
          />
        ))}
      </div>
      
      {/* Input Bar */}
      <InputBar platform="ios" />
    </div>
  );
};

export default IOSChat;