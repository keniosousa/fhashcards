import React from 'react';
import { ArrowLeft, MoreVertical, Phone, Video } from 'lucide-react';
import { Conversation, Message } from '../../types';
import MessageBubble from './MessageBubble';
import InputBar from './InputBar';

interface AndroidChatProps {
  conversation: Conversation;
  editable?: boolean;
  onMessageEdit?: (id: string, text: string) => void;
  onMessageDelete?: (id: string) => void;
}

const AndroidChat: React.FC<AndroidChatProps> = ({
  conversation,
  editable = false,
  onMessageEdit,
  onMessageDelete
}) => {
  const { contact, messages } = conversation;
  
  // Group messages by date (just for display, not actually implemented)
  const messagesWithHeaders = messages;
  
  return (
    <div className="flex flex-col h-full w-full bg-[#E5DDD5] overflow-hidden">
      {/* Header */}
      <div className="android-header flex items-center px-4 py-2 z-10">
        <div className="flex items-center">
          <ArrowLeft size={24} className="text-white mr-3" />
          <div className="h-10 w-10 rounded-full overflow-hidden mr-3">
            <img
              src={contact.photoUrl || 'https://images.pexels.com/photos/614810/pexels-photo-614810.jpeg?auto=compress&cs=tinysrgb&w=200'}
              alt={contact.name}
              className="h-full w-full object-cover"
            />
          </div>
        </div>
        
        <div className="flex-1">
          <h3 className="font-medium text-white">{contact.name}</h3>
          <p className="text-xs text-gray-200">
            {contact.isOnline ? 'online' : contact.lastSeen}
          </p>
        </div>
        
        <div className="flex items-center space-x-6">
          <Video size={20} className="text-white" />
          <Phone size={20} className="text-white" />
          <MoreVertical size={20} className="text-white" />
        </div>
      </div>
      
      {/* Chat Background */}
      <div className="flex-1 overflow-y-auto p-3 space-y-1">
        {messagesWithHeaders.map((message) => (
          <MessageBubble
            key={message.id}
            message={message}
            platform="android"
            editable={editable}
            onEdit={onMessageEdit}
            onDelete={onMessageDelete}
          />
        ))}
      </div>
      
      {/* Input Bar */}
      <InputBar platform="android" />
    </div>
  );
};

export default AndroidChat;