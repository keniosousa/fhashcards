import React from 'react';
import { Smile, Paperclip, Mic, Plus, Camera } from 'lucide-react';

interface InputBarProps {
  platform: 'ios' | 'android';
}

const InputBar: React.FC<InputBarProps> = ({ platform }) => {
  const inputClass = platform === 'ios' ? 'ios-input' : 'android-input';
  
  return (
    <div className="px-3 py-2 bg-gray-100 flex items-center">
      {platform === 'ios' ? (
        <>
          <button className="p-2 text-gray-500">
            <Plus size={22} />
          </button>
          <button className="p-2 text-gray-500">
            <Camera size={22} />
          </button>
          <div className="flex-1 mx-1">
            <div className={`${inputClass} flex items-center pl-3 pr-1 py-1`}>
              <input
                type="text"
                placeholder="Mensagem"
                className="flex-1 bg-transparent border-none outline-none text-sm"
                readOnly
              />
              <button className="p-1 text-gray-500">
                <Smile size={22} />
              </button>
            </div>
          </div>
          <button className="w-10 h-10 rounded-full bg-[#075E54] flex items-center justify-center text-white">
            <Mic size={20} />
          </button>
        </>
      ) : (
        <>
          <button className="p-2 text-gray-500">
            <Smile size={22} />
          </button>
          <div className="flex-1 mx-1">
            <div className={`${inputClass} flex items-center pl-3 pr-1 py-1`}>
              <input
                type="text"
                placeholder="Mensagem"
                className="flex-1 bg-transparent border-none outline-none text-sm"
                readOnly
              />
            </div>
          </div>
          <button className="p-2 text-gray-500">
            <Paperclip size={22} />
          </button>
          <button className="p-2 text-gray-500">
            <Camera size={22} />
          </button>
          <button className="w-10 h-10 rounded-full bg-[#075E54] flex items-center justify-center text-white ml-1">
            <Mic size={20} />
          </button>
        </>
      )}
    </div>
  );
};

export default InputBar;