import React from 'react';
import { Link } from 'react-router-dom';
import { MessageSquare, Instagram, Twitter, Facebook } from 'lucide-react';

const Footer: React.FC = () => {
  return (
    <footer className="bg-white border-t border-gray-200 py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row justify-between items-center">
          <div className="mb-6 md:mb-0">
            <Link to="/" className="flex items-center text-[#075E54] font-bold text-xl">
              <MessageSquare className="mr-2" />
              <span>WhatsApp Prints</span>
            </Link>
            <p className="mt-2 text-sm text-gray-500">
              Crie prints personalizados de conversas do WhatsApp
            </p>
          </div>
          
          <div className="grid grid-cols-2 gap-8 sm:grid-cols-3 sm:gap-6">
            <div>
              <h3 className="text-sm font-semibold text-gray-700 tracking-wider uppercase">
                Links
              </h3>
              <ul className="mt-4 space-y-2">
                <li>
                  <Link to="/" className="text-gray-600 hover:text-[#075E54]">
                    Início
                  </Link>
                </li>
                <li>
                  <Link to="/editor" className="text-gray-600 hover:text-[#075E54]">
                    Editor
                  </Link>
                </li>
                <li>
                  <Link to="/pricing" className="text-gray-600 hover:text-[#075E54]">
                    Preços
                  </Link>
                </li>
              </ul>
            </div>
            
            <div>
              <h3 className="text-sm font-semibold text-gray-700 tracking-wider uppercase">
                Legal
              </h3>
              <ul className="mt-4 space-y-2">
                <li>
                  <Link to="#" className="text-gray-600 hover:text-[#075E54]">
                    Termos de Uso
                  </Link>
                </li>
                <li>
                  <Link to="#" className="text-gray-600 hover:text-[#075E54]">
                    Política de Privacidade
                  </Link>
                </li>
              </ul>
            </div>
            
            <div>
              <h3 className="text-sm font-semibold text-gray-700 tracking-wider uppercase">
                Redes Sociais
              </h3>
              <ul className="mt-4 flex space-x-4">
                <li>
                  <a href="#" className="text-gray-600 hover:text-[#075E54]">
                    <Instagram size={20} />
                  </a>
                </li>
                <li>
                  <a href="#" className="text-gray-600 hover:text-[#075E54]">
                    <Twitter size={20} />
                  </a>
                </li>
                <li>
                  <a href="#" className="text-gray-600 hover:text-[#075E54]">
                    <Facebook size={20} />
                  </a>
                </li>
              </ul>
            </div>
          </div>
        </div>
        
        <div className="mt-8 border-t border-gray-200 pt-8 md:flex md:items-center md:justify-between">
          <p className="text-sm text-gray-500">
            &copy; {new Date().getFullYear()} WhatsApp Prints. Todos os direitos reservados.
          </p>
          <p className="mt-4 text-sm text-gray-500 md:mt-0">
            Este site não é afiliado ao WhatsApp LLC
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;