import React, { useState } from 'react';
import { PlatformType } from '../types';
import useAppStore from '../store';

const EditorControls: React.FC = () => {
  const {
    conversation,
    setPlatform,
    setContactName,
    setContactPhoto,
    setContactOnlineStatus,
    setContactLastSeen,
    addMessage,
    resetConversation,
  } = useAppStore();
  
  const [newMessage, setNewMessage] = useState('');
  const [isSent, setIsSent] = useState(true);
  
  const handleAddMessage = () => {
    if (newMessage.trim()) {
      addMessage(newMessage, isSent);
      setNewMessage('');
    }
  };
  
  const handlePhotoChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.value) {
      setContactPhoto(e.target.value);
    }
  };
  
  return (
    <div className="bg-white rounded-lg shadow-md p-6 space-y-6">
      <div>
        <h3 className="text-lg font-medium text-gray-800 mb-4">Plataforma</h3>
        <div className="flex space-x-4">
          <label className="flex items-center">
            <input
              type="radio"
              name="platform"
              checked={conversation.platform === PlatformType.ANDROID}
              onChange={() => setPlatform(PlatformType.ANDROID)}
              className="mr-2 accent-[#075E54]"
            />
            <span>Android</span>
          </label>
          <label className="flex items-center">
            <input
              type="radio"
              name="platform"
              checked={conversation.platform === PlatformType.IOS}
              onChange={() => setPlatform(PlatformType.IOS)}
              className="mr-2 accent-[#075E54]"
            />
            <span>iOS</span>
          </label>
        </div>
      </div>
      
      <div>
        <h3 className="text-lg font-medium text-gray-800 mb-4">Detalhes do Contato</h3>
        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Nome do Contato
            </label>
            <input
              type="text"
              value={conversation.contact.name}
              onChange={(e) => setContactName(e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-1 focus:ring-[#075E54] focus:border-[#075E54]"
            />
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              URL da Foto (deixe em branco para usar padrão)
            </label>
            <input
              type="text"
              placeholder="https://example.com/photo.jpg"
              onChange={handlePhotoChange}
              className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-1 focus:ring-[#075E54] focus:border-[#075E54]"
            />
          </div>
          
          <div className="flex items-center">
            <input
              type="checkbox"
              checked={conversation.contact.isOnline}
              onChange={(e) => setContactOnlineStatus(e.target.checked)}
              className="mr-2 accent-[#075E54]"
              id="isOnline"
            />
            <label htmlFor="isOnline" className="text-sm text-gray-700">
              Online
            </label>
          </div>
          
          {!conversation.contact.isOnline && (
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Visto por último
              </label>
              <input
                type="text"
                value={conversation.contact.lastSeen}
                onChange={(e) => setContactLastSeen(e.target.value)}
                placeholder="hoje às 14:30"
                className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-1 focus:ring-[#075E54] focus:border-[#075E54]"
              />
            </div>
          )}
        </div>
      </div>
      
      <div>
        <h3 className="text-lg font-medium text-gray-800 mb-4">Mensagens</h3>
        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Nova Mensagem
            </label>
            <textarea
              value={newMessage}
              onChange={(e) => setNewMessage(e.target.value)}
              rows={3}
              className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-1 focus:ring-[#075E54] focus:border-[#075E54]"
              placeholder="Digite sua mensagem aqui"
            />
          </div>
          
          <div className="flex items-center">
            <div className="flex-1">
              <label className="flex items-center">
                <input
                  type="radio"
                  name="messageType"
                  checked={isSent}
                  onChange={() => setIsSent(true)}
                  className="mr-2 accent-[#075E54]"
                />
                <span className="text-sm">Enviada (verde)</span>
              </label>
              <label className="flex items-center mt-1">
                <input
                  type="radio"
                  name="messageType"
                  checked={!isSent}
                  onChange={() => setIsSent(false)}
                  className="mr-2 accent-[#075E54]"
                />
                <span className="text-sm">Recebida (branca)</span>
              </label>
            </div>
            <button
              onClick={handleAddMessage}
              disabled={!newMessage.trim()}
              className="px-4 py-2 bg-[#075E54] text-white rounded-md shadow-sm hover:bg-[#128C7E] focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-[#075E54] disabled:opacity-50 disabled:cursor-not-allowed"
            >
              Adicionar
            </button>
          </div>
        </div>
      </div>
      
      <div className="pt-4 flex justify-end">
        <button
          onClick={resetConversation}
          className="px-4 py-2 border border-gray-300 text-gray-700 rounded-md shadow-sm hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-gray-500 mr-3"
        >
          Resetar
        </button>
      </div>
    </div>
  );
};

export default EditorControls;