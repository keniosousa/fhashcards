import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { MessageSquare } from 'lucide-react';
import useAppStore from '../store';

const Navbar: React.FC = () => {
  const location = useLocation();
  const user = useAppStore((state) => state.user);
  
  return (
    <nav className="bg-white shadow-sm sticky top-0 z-10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-16">
          <div className="flex items-center">
            <Link to="/" className="flex items-center text-[#075E54] font-bold text-xl">
              <MessageSquare className="mr-2" />
              <span>WhatsApp Prints</span>
            </Link>
          </div>
          
          <div className="flex items-center space-x-4">
            <Link 
              to="/" 
              className={`px-3 py-2 rounded-md ${
                location.pathname === '/' 
                  ? 'text-[#075E54] font-medium' 
                  : 'text-gray-700 hover:text-[#075E54]'
              }`}
            >
              Início
            </Link>
            
            <Link 
              to="/editor" 
              className={`px-3 py-2 rounded-md ${
                location.pathname === '/editor' 
                  ? 'text-[#075E54] font-medium' 
                  : 'text-gray-700 hover:text-[#075E54]'
              }`}
            >
              Editor
            </Link>
            
            <Link 
              to="/pricing" 
              className={`px-3 py-2 rounded-md ${
                location.pathname === '/pricing' 
                  ? 'text-[#075E54] font-medium' 
                  : 'text-gray-700 hover:text-[#075E54]'
              }`}
            >
              Preços
            </Link>
            
            <Link 
              to="/about" 
              className={`px-3 py-2 rounded-md ${
                location.pathname === '/about' 
                  ? 'text-[#075E54] font-medium' 
                  : 'text-gray-700 hover:text-[#075E54]'
              }`}
            >
              Sobre
            </Link>
            
            {user.isPremium ? (
              <span className="bg-[#25D366] text-white px-3 py-1 rounded-full text-sm">
                Premium
              </span>
            ) : (
              <Link 
                to="/pricing"
                className="bg-[#075E54] text-white px-4 py-2 rounded-md text-sm font-medium transition-colors hover:bg-[#128C7E]"
              >
                Assinar Premium
              </Link>
            )}
          </div>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;