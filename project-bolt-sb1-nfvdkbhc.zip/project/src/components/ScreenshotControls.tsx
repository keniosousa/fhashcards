import React, { useRef, useState } from 'react';
import { toPng } from 'html-to-image';
import { Download, Camera } from 'lucide-react';
import useAppStore from '../store';

interface ScreenshotControlsProps {
  screenshotRef: React.RefObject<HTMLDivElement>;
}

const ScreenshotControls: React.FC<ScreenshotControlsProps> = ({ screenshotRef }) => {
  const [isGenerating, setIsGenerating] = useState(false);
  const [screenshotUrl, setScreenshotUrl] = useState<string | null>(null);
  const downloadLinkRef = useRef<HTMLAnchorElement>(null);
  
  const { user, incrementScreenshotCount } = useAppStore();
  
  const generateScreenshot = async () => {
    if (!screenshotRef.current) return;
    
    setIsGenerating(true);
    try {
      const dataUrl = await toPng(screenshotRef.current, {
        quality: 0.95,
        pixelRatio: 2
      });
      
      setScreenshotUrl(dataUrl);
      incrementScreenshotCount();
      
      // Auto-click download
      if (downloadLinkRef.current) {
        downloadLinkRef.current.href = dataUrl;
        downloadLinkRef.current.download = `whatsapp-print-${Date.now()}.png`;
      }
    } catch (error) {
      console.error('Error generating screenshot:', error);
    } finally {
      setIsGenerating(false);
    }
  };
  
  const needsSubscription = !user.isPremium && user.freeScreenshotsGenerated >= 1;
  
  return (
    <div className="bg-white rounded-lg shadow-md p-6 space-y-6">
      <div>
        <h3 className="text-lg font-medium text-gray-800 mb-4">
          Gerar Screenshot
        </h3>
        
        <div className="space-y-4">
          <p className="text-sm text-gray-600">
            {needsSubscription 
              ? 'Você já usou sua captura de tela gratuita. Assine o plano Premium para gerar mais capturas!'
              : 'Clique no botão abaixo para gerar e baixar uma captura de tela da conversa.'}
          </p>
          
          <button
            onClick={generateScreenshot}
            disabled={isGenerating || needsSubscription}
            className={`
              w-full flex items-center justify-center px-4 py-3 rounded-md shadow-sm
              focus:outline-none focus:ring-2 focus:ring-offset-2 
              ${needsSubscription
                ? 'bg-gray-300 text-gray-500 cursor-not-allowed'
                : 'bg-[#075E54] text-white hover:bg-[#128C7E] focus:ring-[#075E54]'
              }
            `}
          >
            {isGenerating ? (
              <>
                <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                  <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                  <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                </svg>
                Gerando...
              </>
            ) : (
              <>
                <Camera size={20} className="mr-2" />
                Gerar Screenshot
              </>
            )}
          </button>
          
          {needsSubscription && (
            <div className="mt-4">
              <a 
                href="/pricing"
                className="inline-block w-full text-center px-4 py-2 bg-[#25D366] text-white rounded-md shadow-sm hover:bg-opacity-90 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-[#25D366]"
              >
                Assinar Premium R$19,90/mês
              </a>
            </div>
          )}
        </div>
      </div>
      
      {screenshotUrl && (
        <div className="pt-4 border-t border-gray-200">
          <h4 className="font-medium text-gray-800 mb-3">Sua Screenshot</h4>
          <div className="aspect-[9/16] max-h-[300px] overflow-hidden rounded-md border border-gray-200 mb-3">
            <img 
              src={screenshotUrl} 
              alt="WhatsApp Screenshot" 
              className="w-full h-full object-contain"
            />
          </div>
          <a
            ref={downloadLinkRef}
            href={screenshotUrl}
            download={`whatsapp-print-${Date.now()}.png`}
            className="flex items-center justify-center px-4 py-2 bg-[#128C7E] text-white rounded-md shadow-sm hover:bg-opacity-90 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-[#128C7E]"
          >
            <Download size={18} className="mr-2" />
            Baixar Imagem
          </a>
        </div>
      )}
    </div>
  );
};

export default ScreenshotControls;