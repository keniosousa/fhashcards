import React from 'react';
import { Check, X } from 'lucide-react';
import { Link } from 'react-router-dom';
import useAppStore from '../store';

const PricingPage: React.FC = () => {
  const { user } = useAppStore();
  
  return (
    <div className="py-16 bg-gradient-to-b from-white to-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center">
          <h1 className="text-4xl font-bold text-gray-900">Planos e Preços</h1>
          <p className="mt-4 text-xl text-gray-600 max-w-2xl mx-auto">
            Escolha o plano ideal para gerar seus prints personalizados do WhatsApp
          </p>
        </div>
        
        <div className="mt-16 grid grid-cols-1 md:grid-cols-2 gap-8 max-w-4xl mx-auto">
          {/* Free Plan */}
          <div className="bg-white rounded-lg shadow-md overflow-hidden transition-transform hover:scale-105">
            <div className="px-6 py-8">
              <h2 className="text-2xl font-bold text-gray-900">Gratuito</h2>
              <p className="mt-4 text-gray-600">
                Ideal para experimentar a ferramenta
              </p>
              <p className="mt-6">
                <span className="text-4xl font-bold text-gray-900">R$0</span>
                <span className="text-gray-600 ml-2">para sempre</span>
              </p>
            </div>
            <div className="px-6 pt-6 pb-8">
              <ul className="space-y-4">
                <li className="flex items-start">
                  <Check size={20} className="text-[#075E54] flex-shrink-0 mt-0.5" />
                  <span className="ml-3 text-gray-700">1 print gratuito</span>
                </li>
                <li className="flex items-start">
                  <Check size={20} className="text-[#075E54] flex-shrink-0 mt-0.5" />
                  <span className="ml-3 text-gray-700">Interface Android e iOS</span>
                </li>
                <li className="flex items-start">
                  <Check size={20} className="text-[#075E54] flex-shrink-0 mt-0.5" />
                  <span className="ml-3 text-gray-700">Edição básica</span>
                </li>
                <li className="flex items-start">
                  <X size={20} className="text-red-500 flex-shrink-0 mt-0.5" />
                  <span className="ml-3 text-gray-500">Sem prints ilimitados</span>
                </li>
                <li className="flex items-start">
                  <X size={20} className="text-red-500 flex-shrink-0 mt-0.5" />
                  <span className="ml-3 text-gray-500">Sem recursos avançados</span>
                </li>
              </ul>
              <div className="mt-8">
                <Link
                  to="/editor"
                  className="block w-full px-4 py-3 bg-gray-200 text-gray-800 text-center font-medium rounded-md hover:bg-gray-300 transition-colors"
                >
                  {user.freeScreenshotsGenerated > 0 ? 'Voltar ao Editor' : 'Começar Gratuitamente'}
                </Link>
              </div>
            </div>
          </div>
          
          {/* Premium Plan */}
          <div className="bg-white rounded-lg shadow-md overflow-hidden border-2 border-[#075E54] relative transition-transform hover:scale-105">
            <div className="absolute top-0 right-0 -translate-y-1/2 translate-x-1/2">
              <div className="bg-[#25D366] text-white px-4 py-1 rounded-full text-sm font-bold shadow-md">
                Popular
              </div>
            </div>
            <div className="px-6 py-8">
              <h2 className="text-2xl font-bold text-gray-900">Premium</h2>
              <p className="mt-4 text-gray-600">
                Para quem precisa de mais prints
              </p>
              <p className="mt-6">
                <span className="text-4xl font-bold text-gray-900">R$19,90</span>
                <span className="text-gray-600 ml-2">/mês</span>
              </p>
            </div>
            <div className="px-6 pt-6 pb-8">
              <ul className="space-y-4">
                <li className="flex items-start">
                  <Check size={20} className="text-[#075E54] flex-shrink-0 mt-0.5" />
                  <span className="ml-3 text-gray-700"><strong>Prints ilimitados</strong></span>
                </li>
                <li className="flex items-start">
                  <Check size={20} className="text-[#075E54] flex-shrink-0 mt-0.5" />
                  <span className="ml-3 text-gray-700">Interface Android e iOS</span>
                </li>
                <li className="flex items-start">
                  <Check size={20} className="text-[#075E54] flex-shrink-0 mt-0.5" />
                  <span className="ml-3 text-gray-700">Edição avançada</span>
                </li>
                <li className="flex items-start">
                  <Check size={20} className="text-[#075E54] flex-shrink-0 mt-0.5" />
                  <span className="ml-3 text-gray-700">Alta qualidade de imagem</span>
                </li>
                <li className="flex items-start">
                  <Check size={20} className="text-[#075E54] flex-shrink-0 mt-0.5" />
                  <span className="ml-3 text-gray-700">Suporte prioritário</span>
                </li>
              </ul>
              <div className="mt-8">
                <Link
                  to="/editor"
                  className="block w-full px-4 py-3 bg-[#075E54] text-white text-center font-medium rounded-md hover:bg-[#128C7E] transition-colors"
                >
                  {user.isPremium ? 'Acessar Editor' : 'Assinar Premium'}
                </Link>
              </div>
            </div>
          </div>
        </div>
        
        <div className="mt-16 max-w-3xl mx-auto text-center">
          <h3 className="text-2xl font-bold text-gray-900">Perguntas Frequentes</h3>
          <div className="mt-8 space-y-6 text-left">
            <div>
              <h4 className="text-lg font-medium text-gray-900">Como funciona o período gratuito?</h4>
              <p className="mt-2 text-gray-600">
                Você pode gerar 1 print gratuitamente. Para gerar mais, é necessário assinar o plano Premium.
              </p>
            </div>
            <div>
              <h4 className="text-lg font-medium text-gray-900">Posso cancelar a assinatura a qualquer momento?</h4>
              <p className="mt-2 text-gray-600">
                Sim, você pode cancelar sua assinatura a qualquer momento e continuará tendo acesso ao Premium até o final do período pago.
              </p>
            </div>
            <div>
              <h4 className="text-lg font-medium text-gray-900">Os prints são de alta qualidade?</h4>
              <p className="mt-2 text-gray-600">
                Sim, todos os prints são gerados em alta resolução, perfeitos para uso em mídias sociais, sites e materiais de marketing.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default PricingPage;