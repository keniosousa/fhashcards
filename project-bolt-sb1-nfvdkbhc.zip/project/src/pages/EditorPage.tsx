import React, { useRef } from 'react';
import AndroidChat from '../components/WhatsAppUI/AndroidChat';
import IOSChat from '../components/WhatsAppUI/IOSChat';
import EditorControls from '../components/EditorControls';
import ScreenshotControls from '../components/ScreenshotControls';
import useAppStore from '../store';
import { PlatformType } from '../types';

const EditorPage: React.FC = () => {
  const { conversation, updateMessage, deleteMessage } = useAppStore();
  const screenshotRef = useRef<HTMLDivElement>(null);
  
  return (
    <div className="py-10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <h1 className="text-3xl font-bold text-gray-900 mb-8">Editor de WhatsApp</h1>
        
        <div className="grid grid-cols-1 md:grid-cols-12 gap-6">
          {/* Left Side - Controls */}
          <div className="md:col-span-5 space-y-6">
            <EditorControls />
            <ScreenshotControls screenshotRef={screenshotRef} />
          </div>
          
          {/* Right Side - Preview */}
          <div className="md:col-span-7">
            <div className="bg-white rounded-lg shadow-md p-4 md:p-6">
              <h3 className="text-lg font-medium text-gray-800 mb-4">
                Preview
              </h3>
              
              <div className="aspect-[9/16] mx-auto relative max-w-[360px] border-8 border-black rounded-3xl overflow-hidden">
                {/* Screenshot Area */}
                <div ref={screenshotRef} className="w-full h-full overflow-hidden">
                  {conversation.platform === PlatformType.ANDROID ? (
                    <AndroidChat 
                      conversation={conversation}
                      editable={true}
                      onMessageEdit={updateMessage}
                      onMessageDelete={deleteMessage}
                    />
                  ) : (
                    <IOSChat 
                      conversation={conversation}
                      editable={true}
                      onMessageEdit={updateMessage}
                      onMessageDelete={deleteMessage}
                    />
                  )}
                </div>
              </div>
              
              <div className="mt-4 text-sm text-gray-500 text-center">
                <p>Hover nas mensagens para editar ou excluir</p>
                <p>Esta é apenas uma prévia, gere o screenshot para baixar</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default EditorPage;