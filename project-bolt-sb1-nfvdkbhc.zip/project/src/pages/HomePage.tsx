import React from 'react';
import { Link } from 'react-router-dom';
import { MessageSquare, Edit, Camera, CreditCard, Download } from 'lucide-react';

const HomePage: React.FC = () => {
  return (
    <div className="flex flex-col">
      {/* Hero Section */}
      <section className="relative bg-gradient-to-r from-[#075E54] to-[#128C7E] py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-10 items-center">
            <div>
              <h1 className="text-4xl sm:text-5xl font-bold text-white leading-tight">
                Crie prints de WhatsApp personalizados
              </h1>
              <p className="mt-4 text-xl text-white text-opacity-90">
                Personalize conversas, edite mensagens e gere screenshots realistas do WhatsApp para seus depoimentos e marketing.
              </p>
              <div className="mt-8">
                <Link
                  to="/editor"
                  className="inline-block px-6 py-3 bg-[#25D366] text-white font-medium text-lg rounded-md shadow-lg hover:bg-opacity-90 transition-colors"
                >
                  Criar Meu Print Agora
                </Link>
              </div>
            </div>
            <div className="relative hidden md:block">
              <div className="w-full max-w-[300px] mx-auto">
                <img
                  src="https://images.pexels.com/photos/47261/pexels-photo-47261.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1"
                  alt="WhatsApp Mockup"
                  className="rounded-3xl shadow-2xl border-8 border-white"
                />
              </div>
            </div>
          </div>
        </div>
      </section>
      
      {/* Features Section */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h2 className="text-3xl font-bold text-gray-900">
              Como Funciona
            </h2>
            <p className="mt-4 text-xl text-gray-600 max-w-3xl mx-auto">
              Crie prints do WhatsApp em três passos simples
            </p>
          </div>
          
          <div className="mt-16 grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="flex flex-col items-center p-6 bg-gray-50 rounded-lg">
              <div className="w-14 h-14 rounded-full bg-[#075E54] text-white flex items-center justify-center mb-4">
                <Edit size={24} />
              </div>
              <h3 className="text-xl font-medium text-gray-900">1. Customize</h3>
              <p className="mt-2 text-center text-gray-600">
                Edite nomes, mensagens e detalhes da conversa como desejar
              </p>
            </div>
            
            <div className="flex flex-col items-center p-6 bg-gray-50 rounded-lg">
              <div className="w-14 h-14 rounded-full bg-[#075E54] text-white flex items-center justify-center mb-4">
                <Camera size={24} />
              </div>
              <h3 className="text-xl font-medium text-gray-900">2. Gere</h3>
              <p className="mt-2 text-center text-gray-600">
                Crie um print de alta qualidade com um só clique
              </p>
            </div>
            
            <div className="flex flex-col items-center p-6 bg-gray-50 rounded-lg">
              <div className="w-14 h-14 rounded-full bg-[#075E54] text-white flex items-center justify-center mb-4">
                <Download size={24} />
              </div>
              <h3 className="text-xl font-medium text-gray-900">3. Baixe</h3>
              <p className="mt-2 text-center text-gray-600">
                Faça o download da imagem e use onde quiser
              </p>
            </div>
          </div>
        </div>
      </section>
      
      {/* CTA Section */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="bg-white rounded-2xl shadow-xl overflow-hidden">
            <div className="grid grid-cols-1 md:grid-cols-2">
              <div className="p-8 md:p-12 lg:px-16 lg:py-14">
                <h2 className="text-3xl font-bold text-gray-900">
                  Gere prints ilimitados
                </h2>
                <p className="mt-4 text-lg text-gray-600">
                  Assine o plano premium por apenas R$19,90 por mês e crie quantos prints quiser sem limitações.
                </p>
                <div className="mt-8">
                  <Link
                    to="/pricing"
                    className="inline-flex items-center px-6 py-3 bg-[#075E54] text-white font-medium rounded-md shadow-md hover:bg-[#128C7E] transition-colors"
                  >
                    <CreditCard size={20} className="mr-2" />
                    Ver Planos
                  </Link>
                </div>
              </div>
              <div className="relative">
                <img
                  src="https://images.pexels.com/photos/267350/pexels-photo-267350.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1"
                  alt="Premium WhatsApp Screenshots"
                  className="h-full w-full object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-br from-[#075E54] to-transparent opacity-60"></div>
                <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 text-center text-white">
                  <MessageSquare size={48} className="mx-auto" />
                  <p className="mt-2 text-2xl font-bold">Prints Ilimitados</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default HomePage;