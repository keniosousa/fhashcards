import React from 'react';
import { MessageSquare, Shield, Zap, CheckCircle } from 'lucide-react';
import { Link } from 'react-router-dom';

const AboutPage: React.FC = () => {
  return (
    <div className="py-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="max-w-3xl mx-auto text-center">
          <MessageSquare size={48} className="text-[#075E54] mx-auto" />
          <h1 className="mt-4 text-4xl font-bold text-gray-900">Sobre o WhatsApp Prints</h1>
          <p className="mt-6 text-lg text-gray-600">
            Uma ferramenta poderosa para criar screenshots de conversas do WhatsApp.
            Ideal para marketing, apresentações ou demonstrações de produtos.
          </p>
        </div>
        
        <div className="mt-16">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="bg-white rounded-lg shadow-md p-6">
              <Shield size={32} className="text-[#075E54] mb-4" />
              <h3 className="text-xl font-bold text-gray-900">Segurança</h3>
              <p className="mt-2 text-gray-600">
                Suas informações nunca são armazenadas em nossos servidores.
                Todo o processamento acontece no seu navegador.
              </p>
            </div>
            
            <div className="bg-white rounded-lg shadow-md p-6">
              <Zap size={32} className="text-[#075E54] mb-4" />
              <h3 className="text-xl font-bold text-gray-900">Rápido e Fácil</h3>
              <p className="mt-2 text-gray-600">
                Crie screenshots realistas em segundos, sem necessidade de 
                editar imagens manualmente ou usar software complexo.
              </p>
            </div>
            
            <div className="bg-white rounded-lg shadow-md p-6">
              <CheckCircle size={32} className="text-[#075E54] mb-4" />
              <h3 className="text-xl font-bold text-gray-900">Realista</h3>
              <p className="mt-2 text-gray-600">
                Reproduzimos fielmente a interface do WhatsApp para Android e iOS,
                garantindo screenshots autênticos e convincentes.
              </p>
            </div>
          </div>
        </div>
        
        <div className="mt-16 bg-white rounded-lg shadow-md overflow-hidden">
          <div className="grid grid-cols-1 md:grid-cols-2">
            <div className="p-8 md:p-12">
              <h2 className="text-2xl font-bold text-gray-900">Nossa Missão</h2>
              <p className="mt-4 text-gray-600">
                Criamos o WhatsApp Prints para ajudar empreendedores e profissionais de marketing
                a exibir depoimentos e conversas de forma profissional e atraente.
              </p>
              <p className="mt-4 text-gray-600">
                Nossa ferramenta torna simples a criação de screenshots de alta qualidade
                que podem ser usados em anúncios, sites e materiais promocionais.
              </p>
              <div className="mt-8">
                <Link
                  to="/editor"
                  className="inline-flex items-center px-6 py-3 bg-[#075E54] text-white font-medium rounded-md shadow-md hover:bg-[#128C7E] transition-colors"
                >
                  Experimentar Agora
                </Link>
              </div>
            </div>
            <div className="hidden md:block relative">
              <img
                src="https://images.pexels.com/photos/6476260/pexels-photo-6476260.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1"
                alt="Smartphone com WhatsApp"
                className="h-full w-full object-cover"
              />
            </div>
          </div>
        </div>
        
        <div className="mt-16 max-w-3xl mx-auto text-center">
          <h2 className="text-2xl font-bold text-gray-900">Uso Responsável</h2>
          <p className="mt-4 text-gray-600">
            Pedimos aos nossos usuários que utilizem nossa ferramenta de forma ética e responsável.
            Não incentivamos a criação de conteúdo falso ou enganoso que possa prejudicar terceiros.
          </p>
          <p className="mt-4 text-gray-600">
            Esta ferramenta foi desenvolvida para fins de marketing, educacionais e demonstrativos.
            Recomendamos sempre informar que os screenshots são simulações.
          </p>
        </div>
      </div>
    </div>
  );
};

export default AboutPage;