import { create } from 'zustand';
import { PlatformType, Conversation, Message, User } from '../types';

// Default avatar for contacts
const DEFAULT_AVATAR = 'https://images.pexels.com/photos/614810/pexels-photo-614810.jpeg?auto=compress&cs=tinysrgb&w=200';

interface AppState {
  conversation: Conversation;
  user: User;
  isPreviewMode: boolean;
  screenshotCount: number;
  setUser: (user: User) => void;
  setPlatform: (platform: PlatformType) => void;
  setContactName: (name: string) => void;
  setContactPhoto: (photoUrl: string) => void;
  setContactOnlineStatus: (isOnline: boolean) => void;
  setContactLastSeen: (lastSeen: string) => void;
  addMessage: (text: string, isSent: boolean) => void;
  updateMessage: (id: string, text: string) => void;
  deleteMessage: (id: string) => void;
  togglePreviewMode: () => void;
  incrementScreenshotCount: () => void;
  resetConversation: () => void;
}

// Generate a unique ID
const generateId = () => Math.random().toString(36).substring(2, 10);

// Get formatted current time
const getCurrentTime = () => {
  const now = new Date();
  return now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
};

// Initial state
const initialConversation: Conversation = {
  contact: {
    name: 'João Silva',
    photoUrl: DEFAULT_AVATAR,
    isOnline: true,
    lastSeen: 'online'
  },
  messages: [
    {
      id: generateId(),
      text: 'Oi! Tudo bem?',
      timestamp: getCurrentTime(),
      isSent: false
    },
    {
      id: generateId(),
      text: 'Tudo ótimo! E com você?',
      timestamp: getCurrentTime(),
      isSent: true
    },
    {
      id: generateId(),
      text: 'Estou muito satisfeito com o produto que comprei!',
      timestamp: getCurrentTime(),
      isSent: false
    }
  ],
  platform: PlatformType.ANDROID
};

const initialUser: User = {
  id: generateId(),
  isPremium: false,
  freeScreenshotsGenerated: 0
};

// Create the store
const useAppStore = create<AppState>((set) => ({
  conversation: initialConversation,
  user: initialUser,
  isPreviewMode: false,
  screenshotCount: 0,
  
  setUser: (user) => set({ user }),
  
  setPlatform: (platform) => set((state) => ({
    conversation: { ...state.conversation, platform }
  })),
  
  setContactName: (name) => set((state) => ({
    conversation: {
      ...state.conversation,
      contact: { ...state.conversation.contact, name }
    }
  })),
  
  setContactPhoto: (photoUrl) => set((state) => ({
    conversation: {
      ...state.conversation,
      contact: { ...state.conversation.contact, photoUrl }
    }
  })),
  
  setContactOnlineStatus: (isOnline) => set((state) => ({
    conversation: {
      ...state.conversation,
      contact: { 
        ...state.conversation.contact, 
        isOnline,
        lastSeen: isOnline ? 'online' : state.conversation.contact.lastSeen 
      }
    }
  })),
  
  setContactLastSeen: (lastSeen) => set((state) => ({
    conversation: {
      ...state.conversation,
      contact: { ...state.conversation.contact, lastSeen }
    }
  })),
  
  addMessage: (text, isSent) => set((state) => ({
    conversation: {
      ...state.conversation,
      messages: [
        ...state.conversation.messages,
        {
          id: generateId(),
          text,
          timestamp: getCurrentTime(),
          isSent
        }
      ]
    }
  })),
  
  updateMessage: (id, text) => set((state) => ({
    conversation: {
      ...state.conversation,
      messages: state.conversation.messages.map(message => 
        message.id === id ? { ...message, text } : message
      )
    }
  })),
  
  deleteMessage: (id) => set((state) => ({
    conversation: {
      ...state.conversation,
      messages: state.conversation.messages.filter(message => message.id !== id)
    }
  })),
  
  togglePreviewMode: () => set((state) => ({ isPreviewMode: !state.isPreviewMode })),
  
  incrementScreenshotCount: () => set((state) => ({ 
    screenshotCount: state.screenshotCount + 1,
    user: {
      ...state.user,
      freeScreenshotsGenerated: state.user.freeScreenshotsGenerated + 1
    }
  })),
  
  resetConversation: () => set({ conversation: initialConversation })
}));

export default useAppStore;