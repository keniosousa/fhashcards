export enum PlatformType {
  IOS = 'ios',
  ANDROID = 'android'
}

export interface Message {
  id: string;
  text: string;
  timestamp: string;
  isSent: boolean; // true = sent by user, false = received from contact
}

export interface Contact {
  name: string;
  photoUrl: string;
  isOnline: boolean;
  lastSeen?: string;
}

export interface Conversation {
  contact: Contact;
  messages: Message[];
  platform: PlatformType;
}

export interface User {
  id: string;
  isPremium: boolean;
  freeScreenshotsGenerated: number;
  subscriptionExpiryDate?: string;
}